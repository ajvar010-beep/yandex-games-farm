/* game/main.js — boot-последовательность. Порядок строгий:
   capture.init (парсит URL по белому списку) -> sdk.init -> storage.init -> i18n
   -> scenes -> game.start -> LoadingAPI.ready (1.19.2: игрок уже может начать)
   -> __capture.ready.
   Язык: URL ?lang > сохранённый > ysdk.environment.i18n.lang (2.14). */
(function () {
  'use strict';
  var E = window.Engine, G = window.GAME;

  function boot() {
    var canvas = document.getElementById('game');
    var game = new E.core.Game({ canvas: canvas, bgColor: G.config.palette.bg });
    E.sdk._game = game;
    E.input.attach(canvas);
    E.capture.init(game);
    var cap = E.capture;

    E.sdk.init().then(function () {
      return E.storage.init(E.sdk.ysdk, G.id);
    }).then(function () {
      var savedLang = E.storage.get('lang', null);
      var lang = cap.lang || savedLang || E.sdk.lang || 'en';
      E.i18n.init(G.i18n, lang);
      document.title = E.i18n.t('title');
      E.audio.setMuted(E.storage.get('muted', false) || cap.mute);

      game.addScene('menu', G.scenes.menu);
      game.addScene('play', G.scenes.play);

      // Пауза/возобновление от платформы и рекламы -> пауза ядра.
      // КРИТИЧНО: прокидываем НАСТОЯЩУЮ причину (why) в стек пауз ядра, а не
      // захардкоженный 'sdk'. Иначе рекламная пауза ('ad') и платформенная
      // game_api_pause ('sdk') слились бы в один ключ, и закрытие рекламы
      // снимало бы паузу, хотя платформа всё ещё в game_api_pause. Разные
      // источники = разные ключи стека (_pauseReasons): резюме приходит только
      // когда сняты ВСЕ причины (4.7, 1.19.4).
      E.sdk.onPause(function (why) { game.pause(why || 'sdk'); });
      E.sdk.onResume(function (why) { game.resume(why || 'sdk'); });

      var scene = (cap.scene === 'play' || cap.autoplay || cap.record > 0) ? 'play' : 'menu';
      game.setScene(scene, { seed: cap.seed });
      game.start();

      var b = document.getElementById('boot');
      if (b && b.parentNode) b.parentNode.removeChild(b);

      E.sdk.loadingReady();      // игрок может начать
      E.capture.markReady();     // финальный кадр отрисован, внешний скрипт может работать
      if (cap.record > 0) E.capture.maybeStartRecording();
    }).catch(function (err) {
      // последний рубеж: игра не должна остаться чёрным экраном
      try { console.warn('boot fallback:', err); } catch (e) {}
      try {
        E.i18n.init(G.i18n, 'en');
        game.addScene('menu', G.scenes.menu);
        game.addScene('play', G.scenes.play);
        game.setScene('menu', {});
        game.start();
        var b = document.getElementById('boot');
        if (b && b.parentNode) b.parentNode.removeChild(b);
        E.capture.markReady();
      } catch (e2) {}
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
